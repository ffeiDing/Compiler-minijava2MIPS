import kanga.KangaParser;
import kanga.visitor.Kanga2MipsVisitor;
import minijava.*;
import minijava.ParseException;
import minijava.TokenMgrError;
import minijava.typecheck.*;
import minijava.visitor.*;
import piglet.piglet2spiglet.StoreTemp;
import piglet.visitor.CountTempVisitor;
import piglet.visitor.Piglet2SpigletVisitor;
import piglet.*;
import spiglet.SpigletParser;
import spiglet.spiglet2kanga.*;
import spiglet.visitor.*;
import spiglet.*;
import java.util.*;
import java.io.*;

public class Main {
	public static void main(String [] args) {
		String fileName = "temp";
		try {
			new MiniJavaParser(System.in);
			minijava.syntaxtree.Node rootJava = MiniJavaParser.Goal();
			MyType my_classes = new MyClasses();
			rootJava.accept(new BuildSymbolTableVisitor(), my_classes);
			rootJava.accept(new TypeCheckVisitor(), my_classes);
			if (PrintMsg.errors.size() > 0)
				System.out.println("Type error");
			else {
				FileOutputStream outFile = new FileOutputStream(fileName + ".pg");
				System.setOut(new PrintStream(outFile));
				rootJava.accept(new Minijava2PigletVisitor(), my_classes);

				System.setIn(new FileInputStream(fileName + ".pg"));
				outFile = new FileOutputStream(fileName + ".spg");
				System.setOut(new PrintStream(outFile));
				new PigletParser(System.in);
				piglet.syntaxtree.Node rootPiglet = PigletParser.Goal();
				CountTempVisitor v1 = new CountTempVisitor();
				rootPiglet.accept(v1, null);
				StoreTemp.tempNum = v1.nNum;
				rootPiglet.accept(new Piglet2SpigletVisitor(), null);

				System.setIn(new FileInputStream(fileName + ".spg"));
				outFile= new FileOutputStream(fileName + ".kg");
				System.setOut(new PrintStream(outFile));
				new SpigletParser(System.in);
				spiglet.syntaxtree.Node rootSpiglet = SpigletParser.Goal();

				//存储过程名和过程块的映射
				HashMap<String, FlowGraph> proc_map = new HashMap<String, FlowGraph>();
				//存储每个Label的名字和对应的行数
				HashMap<String, Integer> label_map = new HashMap<String, Integer>();
				rootSpiglet.accept(new FlowGraphNodeVisitor(proc_map, label_map));
				rootSpiglet.accept(new FlowGraphVisitor(proc_map, label_map));
				AssignRegister assign_register = new AssignRegister(proc_map);
				assign_register.assignRegister();
				rootSpiglet.accept(new Spiglet2KangaVisitor(proc_map));

				System.setIn(new FileInputStream(fileName + ".kg"));
				//outFile = new FileOutputStream(fileName + ".s");
				//System.setOut(new PrintStream(outFile));
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
				new KangaParser(System.in);
				kanga.syntaxtree.Node rootKanga = KangaParser.Goal();
				rootKanga.accept(new Kanga2MipsVisitor(), null);
			}
		}
		catch (TokenMgrError | spiglet.ParseException | kanga.ParseException
				| piglet.ParseException | FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (ParseException e) {
			System.out.println(e.toString());
		}

	}
}