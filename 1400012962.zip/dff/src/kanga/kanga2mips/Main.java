package kanga.kanga2mips;
import kanga.visitor.*;
import kanga.syntaxtree.*;
import kanga.*;

public class Main{	
	public static void main(String[] args){
		try{
			new KangaParser(System.in);
			Node root = KangaParser.Goal();
			root.accept(new Kanga2MipsVisitor(), null);				
		} 
		catch(TokenMgrError e){
    		//Handle Lexical Errors
    		e.printStackTrace();
    	}
    	catch (ParseException e){
    		//Handle Grammar Errors
    		e.printStackTrace();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
	}
}
