package minijava.typecheck;
import java.util.*;
/*
 * 所有类的hashmap
 */
public class MyClasses extends MyType{
	
	public int sumClasses = 0;
	public String first_class_name;
	public  HashMap<String, MyClass> mj_classes = new HashMap<String, MyClass>();
	
	public MyClass GetClass(String class_name){
		return mj_classes.get(class_name);
	}
	
	public boolean Repeated(String class_name){
		if(mj_classes.containsKey(class_name) == true){
			return true;
		}
		return false;
	}
	
	public String InsertClass(MyClass v_class){
		if (Repeated(v_class.name) == false){
			mj_classes.put(v_class.name, v_class);
			sumClasses++;
			return null;
		}
		return "CLASS DOUBLE DECLARATION " + "[" + v_class.name + "]";
	}
	
}

