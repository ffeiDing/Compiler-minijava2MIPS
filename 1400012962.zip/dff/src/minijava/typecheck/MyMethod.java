package minijava.typecheck;
import java.util.*;

public class MyMethod extends MyType{
	
	public MyClass owner;
	public String type;
	public HashMap<String, MyVar> mj_var = new HashMap<String, MyVar>();
	public HashMap<String, MyVar> mj_para = new HashMap<String, MyVar>();;
	public Vector<MyVar> mj_para_v = new Vector<MyVar>();
	
	public MyMethod(String v_name, String v_type, MyClass all, int m_line, int m_column){
		name = v_name;
		type = v_type;
		owner = all;
		line = m_line;
		column = m_column;
	}
		
	public MyVar getVar(String var_name){
		MyVar tmp = mj_var.get(var_name);
		if (tmp != null){
			return tmp;
		}
		tmp = mj_para.get(var_name);
		if (tmp != null){
			return tmp;
		}
		MyClass o = owner;
		while ( o != null && !o.getName().equals("None") && !o.getName().equals("")){
			tmp = o.getVar(var_name);
			if (tmp != null){
				return tmp;
			}
			o = o.all_classes.GetClass(o.father);
		}
		return null;
	}
	
	public MyVar getPara(String para_name){
		return mj_para.get(para_name);
		
	}
	
	public boolean Repeated_var(String var_name){
		if (mj_para.containsKey(var_name) == true){
			return true;
		}
		return false;
	}
	
	public String InsertPara(MyVar v_para){
		if (Repeated_var(v_para.name) == false){
			mj_var.put(v_para.name, v_para);
			mj_para.put(v_para.name, v_para);
			mj_para_v.addElement(v_para);
			return null;
		}
		return "PARA DOUBLE DECLARATION " + "[" + v_para.name + "]"; 
	}
	
	public String InsertVar(MyVar v_var){
		if (Repeated_var(v_var.name) == false){
			mj_var.put(v_var.name, v_var);
			return null;
		}
		return "VARIABLE DOUBLE DECLARATION " + "[" + v_var.name + "]";
	}
	
	public int getParaIndex(String para_name){
		int sz = mj_para.size();
		for (int i = 0; i < sz; i++) {
			String c_name = ((MyVar) mj_para_v.elementAt(i)).getName();
			if (c_name.equals(para_name))
				return i;
		}
		return -1;
	}

}
