package minijava.typecheck;

// 用于在Visitor中将一段表达式的类型自下而上传达
// 存储一些无法在符号表中找到的表达式
public class MyTypename extends MyType{
	public String type;
	public String val;
	public MyTypename(String v_type, String v_val, int m_line, int m_column){
		type = v_type;
		if(!v_val.equals(""))
			name = v_val;
		else name = v_type;
		val = v_val;
		line = m_line;
		column = m_column;
	}
}
