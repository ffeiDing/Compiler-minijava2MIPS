package minijava.typecheck;
import java.util.*;

/*
 * 所有类的父类
 */
public class MyType {
	public String name;
	public int line;
	public int column;
	public MyType(){};
	public int getLine(){
		return line;
	}
	public int getColumn(){
		return column;
	}
	public String getName(){
		return name;
	}
}
