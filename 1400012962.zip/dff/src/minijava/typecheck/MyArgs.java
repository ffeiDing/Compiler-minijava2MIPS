package minijava.typecheck;
import java.util.*;

public class MyArgs extends MyType{
	public Vector<MyType> mj_args = new Vector();
	public MyType argu;
	public MyArgs(MyType m_argu){
		argu = m_argu;
	}
	public MyArgs(){
		argu = null;
	}
}
