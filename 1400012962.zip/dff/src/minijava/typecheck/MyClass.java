package minijava.typecheck;
import java.util.*;
/*
 * 类
 */
public class MyClass extends MyType{
	// 所有类的列表
	public MyClasses all_classes;
	// 父节点名称
	public String father;
	// 变量列表 和 方法列表
	public HashMap<String, MyVar> mj_var = new HashMap<String, MyVar>();
	public HashMap<String, MyMethod> mj_method = new HashMap<String, MyMethod>();
	
	public MyClass(String v_name, MyClasses all, int m_line, int m_column){
		name = v_name;
		line = m_line;
		column = m_column;
		all_classes = all;
	}
	
	public boolean Repeated_var(String var_name){
		if(mj_var.containsKey(var_name) == true){
			return true;
		}
		return false;
	}
	
	public boolean Repeated_method(String method_name){
		if(mj_method.containsKey(method_name) == true){
			return true;
		}
		return false;
	}
	
	public String InsertVar(MyVar v_var){
		if (Repeated_var(v_var.name) == false){
			mj_var.put(v_var.name, v_var);
			return null;
		}
		return "VARIABLE DOUBLE DECLARATION " + "[" + v_var.name + "]";
	}
	
	public String InsertMethod(MyMethod v_method){
		if (Repeated_method(v_method.name) == false){
			mj_method.put(v_method.name, v_method);
			return null;
		}
		return "METHOD DOUBLE DECLARATION " + "[" + v_method.name + "]";
	}
	
	public MyVar getVar(String var_name){
		MyVar tmp = mj_var.get(var_name);
		if (tmp != null){
			return tmp;
		}
		String f = father;
		while (!f.equals("None")){
			HashMap<String, MyVar> tmp_var = all_classes.GetClass(f).mj_var;
			tmp = tmp_var.get(var_name);
			if (tmp != null){
				return tmp;
			}
			f = all_classes.GetClass(f).father;
		}
		return null;
	}
	
	public MyMethod getMethod(String method_name){
		MyMethod tmp = mj_method.get(method_name);
		if (tmp != null){
			return tmp;
		}
		String f = father;
		while (!f.equals("None") && !f.equals("") && f!=null){
			HashMap<String, MyMethod> tmp_var = all_classes.GetClass(f).mj_method;
			tmp = tmp_var.get(method_name);
			if (tmp != null){
				return tmp;
			}
			f = all_classes.GetClass(f).father;
		}
		return null;
	}
}
