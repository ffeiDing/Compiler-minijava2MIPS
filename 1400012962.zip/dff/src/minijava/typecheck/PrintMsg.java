package minijava.typecheck;
import java.util.Vector;

public class PrintMsg {
	public static Vector<String> errors = new Vector<String>();
	public static void printMsg(int line, int column, String error_msg){
		String msg = "Line " + line + " Column " + column + ": " + error_msg;
		errors.addElement(msg);
	}
	public static void printAll() {
		int sz = errors.size();
		for (int i = 0; i < sz; i++) {
			System.out.println(errors.elementAt(i));
		}
	}
}