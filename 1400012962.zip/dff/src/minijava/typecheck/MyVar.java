package minijava.typecheck;

public class MyVar extends MyType{
	
	public String type;
	public MyType owner;
	public boolean isInited;
	public boolean isUsed;
	
	public MyVar(String v_name, String v_type, MyType all, int m_line, int m_column){
		name = v_name;
		type = v_type;
		owner = all;
		line = m_line;
		column = m_column;
	}
	
}
