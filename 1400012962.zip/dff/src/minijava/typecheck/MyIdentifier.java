package minijava.typecheck;

// 用来存储程序中出现的各种应该能在符号表中找到的变量名
public class MyIdentifier extends MyType{
	public MyIdentifier(String v_name, int v_line, int v_column){
		name = v_name;
		line = v_line;
		column = v_column;
	}
}
