package minijava.minijava2piglet;
import minijava.MiniJavaParser;
import minijava.TokenMgrError;
import minijava.ParseException;
import minijava.syntaxtree.*;
import minijava.visitor.*;
import minijava.typecheck.*;

public class Main{
	public static void main(String[] args){
		try{	
			new MiniJavaParser(System.in);
			Node root = MiniJavaParser.Goal();

			// 初始化符号表中最大的类 
			MyType my_classes = new MyClasses();

			// 建立符号表，检查重复定义的错误，传入BuildSymbolTableVisitor 
			root.accept(new BuildSymbolTableVisitor(), my_classes);
			
			// 建立完符号表后，检查其余错误，传入TypeCheckVisitor
		    root.accept(new TypeCheckVisitor(), my_classes);
			
			if(PrintMsg.errors.size() > 0)
				System.out.println("Type error");
			
			// 程序没有错误，进行minijava2piglet操作
			if(PrintMsg.errors.size() == 0)
				root.accept(new Minijava2PigletVisitor(), my_classes);				
		} 
		catch(TokenMgrError e){
    		//Handle Lexical Errors
    		e.printStackTrace();
    	}
    	catch (ParseException e){
    		//Handle Grammar Errors
    		e.printStackTrace();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
	}
}