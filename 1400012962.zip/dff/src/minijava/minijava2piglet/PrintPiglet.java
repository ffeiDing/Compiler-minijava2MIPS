package minijava.minijava2piglet;

import java.util.*;
import minijava.visitor.Minijava2PigletVisitor;
import minijava.typecheck.MyClass;

public class PrintPiglet{
	public static int nTab = 0;
	public static boolean enter = false;
	public static void p(String s){
		//需要缩进
		if (enter){
			System.out.println();
			for (int i = 0; i < nTab; i++)
				System.out.print("	");
		}
		//不需要缩进
		enter = false;
		System.out.printf(s);
	}
	//该语句的下一条语句需要缩进
	public static void pln(String s){
		p(s);
		enter = true;
	}
	public static void pMain(){
		nTab++;
		pln("MAIN");
	}
	public static void pEndProcedure(){
		pln("END");
		nTab--;
		pln("");
	}
	public static void pProcedure(String class_name, String method_name, int para_num){
		pln(class_name + "_" + method_name + " [" + para_num + "] ");
		nTab++;
	}
	public static void pBegin(){
		enter = true;
		pln("BEGIN");
		nTab++;
	}
	public static void pEnd(){
		p("END ");
	}
	public static void pReturn(){
		pln("RETURN");
		nTab--;
	}
	
}
