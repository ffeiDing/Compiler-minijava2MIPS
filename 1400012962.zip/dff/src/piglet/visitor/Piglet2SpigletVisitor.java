package piglet.visitor;
import piglet.syntaxtree.*;
import piglet.piglet2spiglet.*;
import minijava.typecheck.*;
import java.util.*;

/**
 * Provides default methods which visit each node in the tree in depth-first
 * order.  Your visitors may extend this class.
 */
public class Piglet2SpigletVisitor extends GJDepthFirst<String, MyType>{
    //
    // Auto class visitors--probably don't need to be overridden.
    //
    int flag = 0;
    int curNum = StoreTemp.tempNum + 1;
    public String visit(NodeListOptional n, MyType argu) {
        String _ret = "";
        if ( n.present()) {
            for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
                _ret += e.nextElement().accept(this,argu);
            }
        }
        return _ret;
    }

    public String visit(NodeOptional n, MyType argu) {
        if ( n.present() )
            System.out.printf(n.node.accept(this,argu));
        return null;
    }


    //
    // User-generated visitor methods below
    //

     /**
      * f0 -> "MAIN"
      * f1 -> StmtList()
      * f2 -> "END"
      * f3 -> ( Procedure() )*
      * f4 -> <EOF>
      */
    public String visit(Goal n, MyType argu) {
        System.out.printf("MAIN ");
        //System.out.printf("Curnum %d\n", curNum);
        System.out.println();
        n.f1.accept(this, argu);
        System.out.println();
        System.out.printf("END ");
        System.out.println();
        n.f3.accept(this, argu);
        return null;
    } 

    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public String visit(Procedure n, MyType argu) {
        System.out.printf(n.f0.accept(this, argu) + "[ " + n.f2.accept(this, argu) + "] ");
        System.out.println();
        System.out.printf("BEGIN");
        System.out.println();
        String tmp = n.f4.accept(this, argu);
        System.out.printf("RETURN " + tmp);
        System.out.println();
        System.out.printf("END");
        System.out.println();
        return "";
    }

    /**
     * f0 -> "NOOP"
     */
    public String visit(NoOpStmt n, MyType argu) {
        System.out.printf("NOOP");
        System.out.println();
        return null;
    }

    /**
     * f0 -> "ERROR"
     */
    public String visit(ErrorStmt n, MyType argu) {
        System.out.printf("ERROR");
        System.out.println();
        return null;
    }

    /**
     * f0 -> "CJUMP"
     * f1 -> Exp()
     * f2 -> Label()
     */
    public String visit(CJumpStmt n, MyType argu) {
        System.out.printf("CJUMP " + n.f1.accept(this, argu) + n.f2.accept(this, argu));
        System.out.println();
        return null;
    }

   /**
    * f0 -> "JUMP"
    * f1 -> Label()
    */
    public String visit(JumpStmt n, MyType argu) {
        System.out.printf("JUMP " + n.f1.accept(this, argu));
        System.out.println();
        return null;
    }

    /**
     * f0 -> "HSTORE"
     * f1 -> Exp()
     * f2 -> IntegerLiteral()
     * f3 -> Exp()
     */
    public String visit(HStoreStmt n, MyType argu) {
        flag = 1;
        String temp = n.f2.accept(this, argu);
        flag = 0;
        System.out.printf("HSTORE " + n.f1.accept(this, argu) + temp + n.f3.accept(this, argu));
        System.out.println();
        return null;
    }

    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Exp()
     * f3 -> IntegerLiteral()
     */
    public String visit(HLoadStmt n, MyType argu) {
        System.out.printf("HLOAD " + n.f1.accept(this, argu) + n.f2.accept(this, argu) + n.f3.accept(this, argu));
        System.out.println();
        return null;
    }

    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public String visit(MoveStmt n, MyType argu) {
        System.out.printf("MOVE " + n.f1.accept(this, argu) + n.f2.accept(this, argu));
        System.out.println();
        return null;
    }

    /**
     * f0 -> "PRINT"
     * f1 -> Exp()
     */
    public String visit(PrintStmt n, MyType argu) {
        System.out.printf("PRINT " + n.f1.accept(this, argu));
        System.out.println();
        return null;
    }

    /**
     * f0 -> StmtExp()
     *       | Call()
     *       | HAllocate()
     *       | BinOp()
     *       | Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public String visit(Exp n, MyType argu) {
        if (n.f0.which == 4)
            return n.f0.accept(this, argu);
        if (n.f0.which == 5 && flag == 1){
            flag = 0;
            return n.f0.accept(this, argu);
        }
        int num = curNum++;
        //System.out.printf("sbbbbbb %d\n", num);
        System.out.printf("MOVE TEMP %d %s", num, n.f0.accept(this, argu));
        System.out.println();
        return "TEMP "+num;
    }

    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> Exp()
     * f4 -> "END"
     */
    public String visit(StmtExp n, MyType argu) {
        n.f1.accept(this, argu);
        return n.f3.accept(this, argu);
    }

    /**
     * f0 -> "CALL"
     * f1 -> Exp()
     * f2 -> "("
     * f3 -> ( Exp() )*
     * f4 -> ")"
     */
    public String visit(Call n, MyType argu) {
        return "CALL " + n.f1.accept(this, argu) + "( " + n.f3.accept(this, argu) + ") ";
    }

    /**
     * f0 -> "HALLOCATE"
     * f1 -> Exp()
     */
    public String visit(HAllocate n, MyType argu) {
        flag = 1;
        String temp = n.f1.accept(this, argu);
        flag = 0;
        return "HALLOCATE " + temp;
    }

    /**
     * f0 -> Operator()
     * f1 -> Exp()
     * f2 -> Exp()
     */
    public String visit(BinOp n, MyType argu) {
        flag = 0;
        return n.f0.accept(this, argu) + n.f1.accept(this, argu) + n.f2.accept(this, argu);
    } 

    /**
     * f0 -> "LT"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     */
    public String visit(Operator n, MyType argu) {
        String[] tmp = {"LT ", "PLUS ", "MINUS ", "TIMES "};
        return tmp[n.f0.which];
    }


    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public String visit(Temp n, MyType argu) {
        return "TEMP "+ n.f1.accept(this, argu);
    }

    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public String visit(IntegerLiteral n, MyType argu) {
        return n.f0.toString() + " ";
    }

    /**
     * f0 -> <IDENTIFIER>
     */
    public String visit(Label n, MyType argu) {
        return n.f0.toString() + " ";
    }

}

