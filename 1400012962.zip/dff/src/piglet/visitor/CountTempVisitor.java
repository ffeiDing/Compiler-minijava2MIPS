package piglet.visitor;
import piglet.syntaxtree.*;
import minijava.typecheck.*;
import piglet.piglet2spiglet.*;
import java.util.*;
// 计算temp从多大开始计数
/**
* Provides default methods which visit each node in the tree in depth-first
* order.  Your visitors may extend this class.
*/
public class CountTempVisitor extends GJDepthFirst<MyType, MyType>{
//
// Auto class visitors--probably don't need to be overridden.
//
	public int nNum = 0;
public MyType visit(NodeList n, MyType argu) {
   MyType _ret=null;
   int _count=0;
   for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
      e.nextElement().accept(this,argu);
      _count++;
   }
   return _ret;
}

public MyType visit(NodeListOptional n, MyType argu) {
   if ( n.present() ) {
      MyType _ret=null;
      int _count=0;
      for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
         e.nextElement().accept(this,argu);
         _count++;
      }
      return _ret;
   }
   else
      return null;
}

public MyType visit(NodeOptional n, MyType argu) {
   if ( n.present() )
      return n.node.accept(this,argu);
   else
      return null;
}

public MyType visit(NodeSequence n, MyType argu) {
   MyType _ret=null;
   int _count=0;
   for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
      e.nextElement().accept(this,argu);
      _count++;
   }
   return _ret;
}

public MyType visit(NodeToken n, MyType argu) { return null; }

//
// User-generated visitor methods below
//

/**
 * f0 -> "MAIN"
 * f1 -> StmtList()
 * f2 -> "END"
 * f3 -> ( Procedure() )*
 * f4 -> <EOF>
 */
public MyType visit(Goal n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   n.f4.accept(this, argu);
   return _ret;
}

/**
 * f0 -> ( ( Label() )? Stmt() )*
 */
public MyType visit(StmtList n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

/**
 * f0 -> Label()
 * f1 -> "["
 * f2 -> IntegerLiteral()
 * f3 -> "]"
 * f4 -> StmtExp()
 */
public MyType visit(Procedure n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   n.f4.accept(this, argu);
   return _ret;
}

/**
 * f0 -> NoOpStmt()
 *       | ErrorStmt()
 *       | CJumpStmt()
 *       | JumpStmt()
 *       | HStoreStmt()
 *       | HLoadStmt()
 *       | MoveStmt()
 *       | PrintStmt()
 */
public MyType visit(Stmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "NOOP"
 */
public MyType visit(NoOpStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "ERROR"
 */
public MyType visit(ErrorStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "CJUMP"
 * f1 -> Exp()
 * f2 -> Label()
 */
public MyType visit(CJumpStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "JUMP"
 * f1 -> Label()
 */
public MyType visit(JumpStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "HSTORE"
 * f1 -> Exp()
 * f2 -> IntegerLiteral()
 * f3 -> Exp()
 */
public MyType visit(HStoreStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "HLOAD"
 * f1 -> Temp()
 * f2 -> Exp()
 * f3 -> IntegerLiteral()
 */
public MyType visit(HLoadStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "MOVE"
 * f1 -> Temp()
 * f2 -> Exp()
 */
public MyType visit(MoveStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "PRINT"
 * f1 -> Exp()
 */
public MyType visit(PrintStmt n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   return _ret;
}

/**
 * f0 -> StmtExp()
 *       | Call()
 *       | HAllocate()
 *       | BinOp()
 *       | Temp()
 *       | IntegerLiteral()
 *       | Label()
 */
public MyType visit(Exp n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "BEGIN"
 * f1 -> StmtList()
 * f2 -> "RETURN"
 * f3 -> Exp()
 * f4 -> "END"
 */
public MyType visit(StmtExp n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   n.f4.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "CALL"
 * f1 -> Exp()
 * f2 -> "("
 * f3 -> ( Exp() )*
 * f4 -> ")"
 */
public MyType visit(Call n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   n.f3.accept(this, argu);
   n.f4.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "HALLOCATE"
 * f1 -> Exp()
 */
public MyType visit(HAllocate n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   return _ret;
}

/**
 * f0 -> Operator()
 * f1 -> Exp()
 * f2 -> Exp()
 */
public MyType visit(BinOp n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   n.f1.accept(this, argu);
   n.f2.accept(this, argu);
   return _ret;
}

/**
 * f0 -> "LT"
 *       | "PLUS"
 *       | "MINUS"
 *       | "TIMES"
 */
public MyType visit(Operator n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

	/**
 	* f0 -> "TEMP"
 	* f1 -> IntegerLiteral()
 	*/
	public MyType visit(Temp n, MyType argu) {
   		MyType _ret=null;
   		n.f0.accept(this, argu);
   		int temp = Integer.parseInt(n.f1.f0.toString());
   		if (temp > nNum)
   			nNum = temp;
   		n.f1.accept(this, argu);
   		return _ret;
	}

/**
 * f0 -> <INTEGER_LITERAL>
 */
public MyType visit(IntegerLiteral n, MyType argu) {
   return n.f0.accept(this, argu);
}

/**
 * f0 -> <IDENTIFIER>
 */
public MyType visit(Label n, MyType argu) {
   MyType _ret=null;
   n.f0.accept(this, argu);
   return _ret;
}

}

