package piglet.piglet2spiglet;
import piglet.PigletParser;
import piglet.TokenMgrError;
import piglet.ParseException;
import piglet.syntaxtree.*;
import piglet.visitor.*;


public class Main{	
	public static void main(String[] args){
		try{
			new PigletParser(System.in);
			Node root = PigletParser.Goal();
            CountTempVisitor v1 = new CountTempVisitor();
			root.accept(v1, null);
            StoreTemp.tempNum = v1.nNum;
            Piglet2SpigletVisitor v2 = new Piglet2SpigletVisitor();
            root.accept(v2, null);				
		} 
		catch(TokenMgrError e){
    		//Handle Lexical Errors
    		e.printStackTrace();
    	}
    	catch (ParseException e){
    		//Handle Grammar Errors
    		e.printStackTrace();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
	}
}
