package piglet.piglet2spiglet;

public class StoreTemp{
	public static int tempNum = 0;
}
