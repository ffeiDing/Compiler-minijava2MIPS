package spiglet.visitor;
import spiglet.syntaxtree.*;
import spiglet.spiglet2kanga.*;
import minijava.typecheck.*;
import java.util.*;

//为每个语句建立一个结点
public class FlowGraphNodeVisitor extends GJNoArguDepthFirst<String>{
	//存储过程名和过程块的映射
	private HashMap<String, FlowGraph> proc_map;
	//存储每个Label的名字和对应的行数
	private HashMap<String, Integer> label_map;
	private FlowGraph proc_cur;
	private FlowGraphNode node_cur;
	private int line;

	public FlowGraphNodeVisitor(HashMap<String, FlowGraph> _proc_map, HashMap<String, Integer> _label_map){
		this.proc_map = _proc_map;
		this.label_map = _label_map;
		this.line = 0;
	}
	
   	public String visit(NodeListOptional n) {
      	if ( n.present() ) {
        	Integer _count=0;
         	for ( Enumeration<Node> e = n.elements(); e.hasMoreElements(); ) {
            	e.nextElement().accept(this);
            	_count++;
         	}
         	return _count.toString();
      	}
    	return null;
   	}

   	//添加label的名字和对应的行数到label_map中
   	public String visit(NodeOptional n) {
      	if ( n.present() ){
         	label_map.put(n.node.accept(this), line);
      	}
      	return null;
   	}

   /**
    * f0 -> "MAIN"
    * f1 -> StmtList()
    * f2 -> "END"
    * f3 -> ( Procedure() )*
    * f4 -> <EOF>
    */
    public String visit(Goal n) {
    	line = 0;
    	proc_cur = new FlowGraph("MAIN", 0, line);//MAIN函数，参数为0个, 行数为0
    	proc_map.put("MAIN", proc_cur);
    	proc_cur.addNode(line++);//MAIN
    	n.f1.accept(this);
    	proc_cur.addNode(line);//END
      	n.f3.accept(this);
      	return null;
   	}

   /**
    * f0 -> Label()
    * f1 -> "["
    * f2 -> IntegerLiteral()
    * f3 -> "]"
    * f4 -> StmtExp()
    */
   	public String visit(Procedure n) {
   		line = 0;
   		String name = n.f0.f0.toString();
   		proc_cur = new FlowGraph(name, Integer.parseInt(n.f2.accept(this)), line);
    	proc_map.put(name, proc_cur);
    	n.f2.accept(this);
      	n.f4.accept(this);
      	return null;
   	}

   /**
    * f0 -> NoOpStmt()
    *       | ErrorStmt()
    *       | CJumpStmt()
    *       | JumpStmt()
    *       | HStoreStmt()
    *       | HLoadStmt()
    *       | MoveStmt()
    *       | PrintStmt()
    */
   	public String visit(Stmt n) {
        proc_cur.addNode(line);
    	n.f0.accept(this);
    	line++;
      	return null;
   	}

   	/**
    * f0 -> "CALL"
    * f1 -> SimpleExp()
    * f2 -> "("
    * f3 -> ( Temp() )*
    * f4 -> ")"
    */
   	//计算过程的max_para
   	public String visit(Call n) {
      	n.f1.accept(this);
      	n.f3.accept(this);
      	proc_cur.call_pos.add(line);
      	int tmp = n.f3.size();
      	if (tmp > proc_cur.max_para_num)
      		proc_cur.max_para_num = tmp;
      	return null;
   	}

   /**
    * f0 -> "BEGIN"
    * f1 -> StmtList()
    * f2 -> "RETURN"
    * f3 -> SimpleExp()
    * f4 -> "END"
    */
   	public String visit(StmtExp n) {
   		proc_cur.addNode(line++);//BEGIN
      	n.f1.accept(this);
      	proc_cur.addNode(line++);//RETURN
    	n.f3.accept(this);
      	proc_cur.addNode(line++);//END
    	return null;
   	}

   	/**
    * f0 -> "TEMP"
    * f1 -> IntegerLiteral()
    */
   	public String visit(Temp n) {
      	int id = Integer.parseInt(n.f1.accept(this));
      	if (!proc_cur.tmp_map.containsKey(id)){
      		if(id < proc_cur.para_num){
      			Register reg_cur = new Register(id, 0, line);
      			proc_cur.tmp_map.put(id, reg_cur);
      		}
      		else{
      			Register reg_cur = new Register(id, line, line);
      			proc_cur.tmp_map.put(id, reg_cur);
      		}
      	}
      	return null;
   	}

   /**
    * f0 -> <INTEGER_LITERAL>
    */
   	public String visit(IntegerLiteral n) {
     	return n.f0.toString();
   	}

   /**
    * f0 -> <IDENTIFIER>
    */
   	public String visit(Label n) {
    	return n.f0.toString();
   	}

}

