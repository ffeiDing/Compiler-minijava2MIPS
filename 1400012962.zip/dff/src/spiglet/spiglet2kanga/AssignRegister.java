package spiglet.spiglet2kanga;
import java.util.*;

public class AssignRegister {
	public HashMap<String, FlowGraph> proc_map;
	public FlowGraph proc_cur;
	public FlowGraphNode node_cur;
	public Register reg_cur;
	Register[] setT;
	Register[] setS;
	PriorityQueue<Register> active;
	int flag = 1;
	int emptyT, emptyS;
	int longestT, longestS;

	public AssignRegister(HashMap<String, FlowGraph> _proc_map){
		proc_map = _proc_map;
	}

	public void livenessAnalysis(){
		flag = 1;
		while(flag == 1){
			flag = 0;
			for (int i = proc_cur.vNode.size() - 1; i >= 0; i--){
				FlowGraphNode node_cur = proc_cur.nodes.get(i);
				for (Map.Entry<Integer, FlowGraphNode> entry2: node_cur.after_nodes.entrySet()){
					node_cur.out.addAll((entry2.getValue()).in);
				}
				HashSet<Integer> new_in = new HashSet<Integer>();
				new_in.addAll(node_cur.out);
				new_in.removeAll(node_cur.def);
				new_in.addAll(node_cur.use);
				if(!new_in.equals(node_cur.in)){
					node_cur.in = new_in;
					flag = 1;
				}
			}
		}
	}

	public void getInterval(){
		for (Map.Entry<Integer, FlowGraphNode> entry1: proc_cur.nodes.entrySet()){
			node_cur = entry1.getValue();
			for (Integer i: node_cur.in){
				if (node_cur.line < ((proc_cur.tmp_map).get(i)).begin)
					((proc_cur.tmp_map).get(i)).begin = node_cur.line;
				if (node_cur.line > ((proc_cur.tmp_map).get(i)).end)
					((proc_cur.tmp_map).get(i)).end = node_cur.line;
			}
			for (Integer j: node_cur.out){
				if (node_cur.line < ((proc_cur.tmp_map).get(j)).begin)
					((proc_cur.tmp_map).get(j)).begin = node_cur.line;
				if (node_cur.line > ((proc_cur.tmp_map).get(j)).end)
					((proc_cur.tmp_map).get(j)).end = node_cur.line;
			}
		}
		for (Map.Entry<Integer, Register> entry2: proc_cur.tmp_map.entrySet()){
			reg_cur = entry2.getValue();
			for (Integer k: proc_cur.call_pos){
				if (reg_cur.begin < k && reg_cur.end > k){
					reg_cur.isS = true;
					break;
				}
			}
		}
	} 

	public void assignRegister(){
		for (Map.Entry<String, FlowGraph> entry1: proc_map.entrySet()){
			proc_cur = entry1.getValue();
			livenessAnalysis();
			getInterval();
			setT = new Register[10];
			setS = new Register[8];
			int stackUse = 0;
			active = new PriorityQueue<>(Register::compareAsEnd);
			ArrayList<Register> itvs = new ArrayList<>();
			for(Register itv : proc_cur.tmp_map.values()){
				itvs.add(itv);
			}
			itvs.sort(Register::compareAsBegin);
			for(Register itv: itvs){
				emptyS = -1;
				emptyT = -1;
				longestS = -1;
				longestT = -1;
				for (int m = 9; m >= 0; m--){
					if (setT[m] != null){
						if (setT[m].end <= itv.begin){
							proc_cur.regT.put(setT[m], m);
							setT[m] = null;
							emptyT = m;
						}
						else{
							if(longestT == -1 || setT[m].end > setT[longestT].end)
								longestT = m;
						}
					}
					else{
						emptyT = m;
					}
				}

				for (int m = 7; m >= 0; m--){
					if (setS[m] != null){
						if (setS[m].end <= itv.begin){
							proc_cur.regS.put(setS[m], m);
							setS[m] = null;
							emptyS = m;
						}
						else{
							if(longestS == -1 || setS[m].end > setS[longestS].end)
								longestS = m;
						}
					}
					else{
						emptyS = m;
					}
				}

				if(itv != null && !itv.isS){
					if(emptyT != -1){
						setT[emptyT] = itv;
						itv = null;
					}else{
						if(itv.end < setT[longestT].end){
							Register tmp = setT[longestT];
							setT[longestT] = itv;
							itv = tmp;
						}
					}
				}

				if(itv != null){
					if(emptyS != -1){
						setS[emptyS] = itv;
						itv = null;
					}else{
						if(itv.end < setS[longestS].end){
							Register tmp = setS[longestS];
							setS[longestS] = itv;
							itv = tmp;
						}
					}
				}

				if(itv != null)
					proc_cur.stack.put(itv, 0);
			}
			for(int l = 0; l < 10; l ++){
				if(setT[l] != null)
					proc_cur.regT.put(setT[l], l);
			}
			for(int l = 0; l < 8; l ++){
				if(setS[l] != null)
					proc_cur.regS.put(setS[l], l);
			}
			int spilledIdx = (proc_cur.para_num > 4 ? proc_cur.para_num - 4 : 0) + proc_cur.regS.size();
			for(Register s : proc_cur.stack.keySet()){
				proc_cur.stack.put(s, spilledIdx);
				spilledIdx ++;
			}
			proc_cur.stack_num = spilledIdx;
		}
	}
}
