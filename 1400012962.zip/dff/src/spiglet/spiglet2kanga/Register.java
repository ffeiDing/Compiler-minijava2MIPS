package spiglet.spiglet2kanga;

public class Register {
	public int id;
	public int begin;
	public int end;
	public boolean isS;

	public Register(int _id, int _begin, int _end){
		id = _id;
		begin = _begin;
		end = _end;
		isS = false;
	}
	public int compareAsBegin(Register compareRegister){
		return this.begin - compareRegister.begin;
	}
	public int compareAsEnd(Register compareRegister){
		return this.end - compareRegister.end;
	}
}
