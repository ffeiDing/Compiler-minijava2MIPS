package spiglet.spiglet2kanga;
import java.util.*;

public class FlowGraph {
	public String name;
	public int line;
	public int para_num;
	public int stack_num;
	public int max_para_num;
	public HashMap<Integer, FlowGraphNode> nodes;
	public Vector<FlowGraphNode> vNode;
	public HashSet<Integer> call_pos;
	public HashMap<Integer, Register> tmp_map;
	public HashMap<Register, Integer> regT;
	public HashMap<Register, Integer> regS;
	public HashMap<Register, Integer> stack;

	public FlowGraph(String _name, int _para_num, int _line){
		nodes = new HashMap<Integer, FlowGraphNode>();
		vNode = new Vector<FlowGraphNode>();
		call_pos = new HashSet<Integer>();
		tmp_map = new HashMap<Integer, Register>();
		regT = new HashMap<Register, Integer>();
		regS = new HashMap<Register, Integer>();
		stack = new HashMap<Register, Integer>();
		name = _name;
		para_num = _para_num;
		max_para_num = 0;
		line = _line;
	}

	public void addEdge(int line1, int line2){
		FlowGraphNode before = nodes.get(line1);
		FlowGraphNode after = nodes.get(line2);
		before.after_nodes.put(line2, after);
		after.before_nodes.put(line1, after);
	}

	public void addNode(int _line){
		FlowGraphNode v = new FlowGraphNode(_line);
		this.vNode.add(v);
		this.nodes.put(_line, v);
	}

}
