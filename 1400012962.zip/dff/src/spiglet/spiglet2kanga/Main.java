package spiglet.spiglet2kanga;

import spiglet.ParseException;
import spiglet.SpigletParser;
import spiglet.TokenMgrError;
import spiglet.syntaxtree.Node;
import spiglet.visitor.FlowGraphNodeVisitor;
import spiglet.visitor.FlowGraphVisitor;
import spiglet.visitor.Spiglet2KangaVisitor;

import java.util.*;

public class Main{	
	public static void main(String[] args){
		try{
			new SpigletParser(System.in);
			Node root = SpigletParser.Goal();
            //存储过程名和过程块的映射
            HashMap<String, FlowGraph> proc_map = new HashMap<String, FlowGraph>();
            //存储每个Label的名字和对应的行数
            HashMap<String, Integer> label_map = new HashMap<String, Integer>();
            root.accept(new FlowGraphNodeVisitor(proc_map, label_map));
            root.accept(new FlowGraphVisitor(proc_map, label_map));
            AssignRegister assign_register = new AssignRegister(proc_map);
            assign_register.assignRegister();
			root.accept(new Spiglet2KangaVisitor(proc_map));			
		} 
		catch(TokenMgrError e){
    		//Handle Lexical Errors
    		e.printStackTrace();
    	}
    	catch (ParseException e){
    		//Handle Grammar Errors
    		e.printStackTrace();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
	}
}
