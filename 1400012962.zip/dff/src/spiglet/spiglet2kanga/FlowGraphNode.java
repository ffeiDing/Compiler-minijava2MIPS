package spiglet.spiglet2kanga;
import java.util.*;

public class FlowGraphNode {
	public int line;
	public HashMap<Integer, FlowGraphNode> before_nodes;
	public HashMap<Integer, FlowGraphNode> after_nodes;
	public HashSet<Integer> use;
	public HashSet<Integer> def;
	public HashSet<Integer> in;
	public HashSet<Integer> out;
	public FlowGraphNode(int _line){
		line = _line;
		use = new HashSet<Integer>();
		def = new HashSet<Integer>();
		in = new HashSet<Integer>();
		out = new HashSet<Integer>();
		before_nodes = new HashMap<Integer, FlowGraphNode>();
		after_nodes = new HashMap<Integer, FlowGraphNode>();
	}
}
